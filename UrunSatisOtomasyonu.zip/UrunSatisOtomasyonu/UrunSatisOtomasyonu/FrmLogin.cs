﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UrunSatisOtomasyonu
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtKullaniciAdi.Text=="" || txtParola.Text=="")
                MessageBox.Show("Lütfen kullanıcı adı ve parola bilgilerinizi giriniz ", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                if (txtKullaniciAdi.Text=="admin" && txtParola.Text=="123")
                {
                    FrmAnamenu frm = new FrmAnamenu();
                    frm.Show();
                    this.Hide(); 
                }
                else
                    MessageBox.Show("Hatalı kullanıcı adı/parola ", "Hata ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            txtKullaniciAdi.Text = "";
            txtParola.Text = ""; 


        }
    }
}
